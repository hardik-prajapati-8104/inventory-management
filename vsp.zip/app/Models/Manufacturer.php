<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Manufacturer extends Model
{
    protected $fillable = ['name', 'country', 'logo', 'status'];
    protected $casts = ['status' => 'boolean'];
}
