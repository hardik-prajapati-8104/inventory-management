<?php
    $menu = $menu ?? null;
    $old = fn($field, $default = null) => old($field, $menu->$field ?? $default);
?>

<div class="row g-3">
    <div class="col-md-6">
        <label>Type<span class="text-error">*</span></label>
        <select name="type" id="menuType" class="form-select" required>
            <option value="link" <?php echo e($old('type', 'link') === 'link' ? 'selected' : ''); ?>>Link (clickable nav item)
            </option>
            <option value="heading" <?php echo e($old('type') === 'heading' ? 'selected' : ''); ?>>Heading (section label, e.g.
                "Inventory")</option>
        </select>
        <div class="form-text"> A heading is a non-clickable section label. It can contain menu items below it.</div>
    </div>

    <div class="col-md-6">
        <label>Name<span class="text-error">*</span></label>
        <input type="text" name="name" required maxlength="100" class="form-control" value="<?php echo e($old('name')); ?>"
            placeholder="e.g. Spare Parts">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-error small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6" id="parentField">

        <label for="parent_id">
            Parent Menu
        </label>

        <select name="parent_id" id="parent_id" class="form-select">

            <option value="">None (top level)</option>

            <?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>"
                    <?php if((string) $old('parent_id') === (string) $p->id): echo 'selected'; endif; ?>>
                    <?php echo e($p->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>

        <div class="form-text">
             Select a top-level menu or section heading to place this item inside its menu group.
            Leave as <strong>None</strong> to create a top-level menu.
        </div>

        <?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-error small">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>

    <div class="col-md-6">
        <label>Icon (Bootstrap Icon class)</label>
        <div class="input-group">
            <span class="input-group-text"><i class="bi" id="iconPreview"><?php echo e(''); ?></i></span>
            <input type="text" name="icon" id="iconInput" maxlength="50" class="form-control"
                value="<?php echo e($old('icon')); ?>" placeholder="e.g. bi-gear-wide-connected">
        </div>
        <div class="form-text">Browse classes at <a href="https://icons.getbootstrap.com" target="_blank"
                rel="noopener">icons.getbootstrap.com</a> — paste the "bi-..." class shown there.</div>
    </div>

    <div class="col-12">
        <hr class="my-1">
    </div>

    <div class="col-md-6" id="routeNameField">
        <label>Route Name</label>
        <input type="text" name="route_name" id="routeNameInput" maxlength="150" class="form-control"
            value="<?php echo e($old('route_name')); ?>" placeholder="e.g. admin.spare-parts.index">
        <div class="form-text" id="routeNameStatus">Preferred over URL below — resolved with Laravel's
            <code>route()</code> helper, so it survives URL prefix changes. Leave URL blank if you set this.</div>
        <?php $__errorArgs = ['route_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-error small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6" id="urlField">
        <label>URL</label>
        <input type="text" name="url" maxlength="255" class="form-control" value="<?php echo e($old('url')); ?>"
            placeholder="e.g. https://example.com or /admin/custom-page">
        <div class="form-text">Only used when Route Name above is blank or invalid.</div>
        <?php $__errorArgs = ['url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-error small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-md-6" id="activePatternField">
        <label>Active-State Pattern <span class="text-muted small">(optional)</span></label>
        <input type="text" name="active_pattern" maxlength="150" class="form-control"
            value="<?php echo e($old('active_pattern')); ?>" placeholder="e.g. admin.spare-parts.*">
        <div class="form-text">Wildcard route pattern that keeps this item highlighted on sub-pages. Auto-filled from
            Route Name if left blank.</div>
    </div>

    <div class="col-md-6">
        <label>Required Permission</label>
        <select name="permission" class="form-select">
            <option value="">None — visible to any logged-in admin</option>
            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($perm); ?>" <?php echo e($old('permission') === $perm ? 'selected' : ''); ?>>
                    <?php echo e($perm); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <div class="form-text">Only admins who have this permission (or Super Admins) will see this item in the sidebar.
        </div>
        <?php $__errorArgs = ['permission'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-error small"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="col-12">
        <hr class="my-1">
    </div>

    <div class="col-md-4" id="targetField">
        <label>Open In</label>
        <select name="target" class="form-select">
            <option value="_self" <?php echo e($old('target', '_self') === '_self' ? 'selected' : ''); ?>>Same tab</option>
            <option value="_blank" <?php echo e($old('target') === '_blank' ? 'selected' : ''); ?>>New tab</option>
        </select>
    </div>

    <div class="col-md-4">
        <label>Sort Order</label>
        <input type="number" name="sort_order" min="0" class="form-control"
            value="<?php echo e($old('sort_order', 0)); ?>">
        <div class="form-text">Lower numbers appear first. You can also drag items into order from the list.</div>
    </div>

    <div class="col-md-4">
        <label class="d-block">Status</label>
        <div class="form-check form-switch mt-2">
            <input class="form-check-input" type="checkbox" role="switch" name="status" value="1"
                id="statusSwitch" <?php echo e($old('status', true) ? 'checked' : ''); ?>>
            <label class="form-check-label" for="statusSwitch">Active (shown in sidebar)</label>
        </div>
    </div>
</div>

<script>
    (function() {
        const typeSelect = document.getElementById('menuType');
        const parentField = document.getElementById('parentField');
        const routeField = document.getElementById('routeNameField');
        const urlField = document.getElementById('urlField');
        const activeField = document.getElementById('activePatternField');
        const targetField = document.getElementById('targetField');

        function toggleLinkOnlyFields() {
            const isHeading = typeSelect.value === 'heading';
            [parentField, routeField, urlField, activeField, targetField].forEach(function(el) {
                if (!el) return;
                el.style.display = isHeading ? 'none' : '';
            });
        }
        typeSelect?.addEventListener('change', toggleLinkOnlyFields);
        toggleLinkOnlyFields();

        const iconInput = document.getElementById('iconInput');
        const iconPreview = document.getElementById('iconPreview');

        function updateIconPreview() {
            iconPreview.className = 'bi ' + (iconInput.value.trim() || 'bi-question-circle');
        }
        iconInput?.addEventListener('input', updateIconPreview);
        updateIconPreview();

        const routeInput = document.getElementById('routeNameInput');
        const routeStatus = document.getElementById('routeNameStatus');
        const checkRouteUrl = <?php echo json_encode(route('admin.menus.check-route'), 15, 512) ?>;
        let routeCheckTimer = null;
        routeInput?.addEventListener('input', function() {
            clearTimeout(routeCheckTimer);
            const name = routeInput.value.trim();
            if (!name) {
                routeStatus.innerHTML =
                    'Preferred over URL below — resolved with Laravel\'s <code>route()</code> helper, so it survives URL prefix changes. Leave URL blank if you set this.';
                routeStatus.classList.remove('text-success', 'text-error');
                return;
            }
            routeCheckTimer = setTimeout(function() {
                fetch(checkRouteUrl + '?route_name=' + encodeURIComponent(name))
                    .then(function(r) {
                        return r.json();
                    })
                    .then(function(data) {
                        routeStatus.classList.remove('text-success', 'text-error');
                        if (data.exists) {
                            routeStatus.classList.add('text-success');
                            routeStatus.textContent = '✓ Route found (resolves to ' + data.url +
                                ')';
                        } else {
                            routeStatus.classList.add('text-error');
                            routeStatus.textContent = '✗ No route named "' + name +
                                '" exists. Double check spelling, or use the URL field instead.';
                        }
                    })
                    .catch(function() {
                        /* non-fatal — validation still happens on submit */ });
            }, 400);
        });
    })();
</script>
<?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/menus/_form.blade.php ENDPATH**/ ?>