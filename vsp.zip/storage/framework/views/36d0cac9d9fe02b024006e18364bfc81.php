<?php $__env->startSection('title'); ?>
Vehicle Management - Vehicle Spare Parts Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-12">
            <h4 class="page-title mb-1">Vehicle Management</h4>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><span>Vehicle Management</span></li>
            </ul>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#makes" type="button">Makes (<?php echo e($makes->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#models" type="button">Models (<?php echo e($models->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#variants" type="button">Variants (<?php echo e($variants->count()); ?>)</button></li>
        </ul>

        <div class="tab-content pt-4">

            
            <div class="tab-pane fade show active" id="makes">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Make</h6>
                        <form action="<?php echo e(route('admin.vehicles.makes.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <input type="text" name="name" required class="form-control" placeholder="e.g. Toyota">
                            </div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Make</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th width="5%">#</th><th>Make</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($make->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="2" class="text-center text-muted py-3">No makes yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="models">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Model</h6>
                        <form action="<?php echo e(route('admin.vehicles.models.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label>Make<span class="text-error">*</span></label>
                                <select name="vehicle_make_id" required class="form-select">
                                    <option value="">Select Make</option>
                                    <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($make->id); ?>"><?php echo e($make->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Vehicle Type</label>
                                <select name="vehicle_type_id" class="form-select">
                                    <option value="">Select Type</option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Model Name<span class="text-error">*</span></label>
                                <input type="text" name="name" required class="form-control" placeholder="e.g. Corolla">
                            </div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Model</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th width="5%">#</th><th>Make</th><th>Model</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($model->make->name ?? '-'); ?></td><td><?php echo e($model->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="3" class="text-center text-muted py-3">No models yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="variants">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Variant</h6>
                        <form action="<?php echo e(route('admin.vehicles.variants.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label>Make<span class="text-error">*</span></label>
                                <select id="variantMake" required class="form-select">
                                    <option value="">Select Make</option>
                                    <?php $__currentLoopData = $makes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $make): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($make->id); ?>"><?php echo e($make->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Model<span class="text-error">*</span></label>
                                <select name="vehicle_model_id" id="variantModel" required class="form-select" disabled>
                                    <option value="">Select Make first</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Variant Name<span class="text-error">*</span></label>
                                <input type="text" name="name" required class="form-control" placeholder="e.g. 1.8L">
                            </div>
                            <div class="row g-2">
                                <div class="col-6 mb-3">
                                    <label>Start Year</label>
                                    <input type="number" name="start_year" class="form-control" placeholder="2018">
                                </div>
                                <div class="col-6 mb-3">
                                    <label>End Year</label>
                                    <input type="number" name="end_year" class="form-control" placeholder="2022">
                                </div>
                            </div>
                            <div class="mb-3">
                                <label>Fuel Type</label>
                                <select name="fuel_type" class="form-select">
                                    <option value="">-</option>
                                    <?php $__currentLoopData = ['Petrol','Diesel','Hybrid','Electric','CNG','LPG']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($f); ?>"><?php echo e($f); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label>Transmission</label>
                                <select name="transmission" class="form-select">
                                    <option value="">-</option>
                                    <?php $__currentLoopData = ['Manual','Automatic','CVT']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($t); ?>"><?php echo e($t); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Variant</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th width="5%">#</th><th>Make</th><th>Model</th><th>Variant</th><th>Years</th><th>Fuel</th><th width="8%"></th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($v->model_->make->name ?? '-'); ?></td>
                                    <td><?php echo e($v->model_->name ?? '-'); ?></td>
                                    <td><?php echo e($v->name); ?></td>
                                    <td><?php echo e($v->start_year); ?><?php echo e($v->end_year ? '-'.$v->end_year : ($v->start_year ? '+' : '')); ?></td>
                                    <td><?php echo e($v->fuel_type ?? '-'); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('admin.vehicles.variants.destroy', $v->id)); ?>" method="POST" onsubmit="return confirm('Delete this variant?');">
                                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7" class="text-center text-muted py-3">No variants yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // Cascading Make -> Model dropdown, shared logic with the Spare Part
    // compatibility tab (see spare-parts/partials/tab-vehicles.blade.php).
    document.getElementById('variantMake')?.addEventListener('change', function () {
        const modelSelect = document.getElementById('variantModel');
        const makeId = this.value;

        modelSelect.innerHTML = '<option value="">Loading…</option>';
        modelSelect.disabled = true;

        if (! makeId) {
            modelSelect.innerHTML = '<option value="">Select Make first</option>';
            return;
        }

        fetch(`<?php echo e(url('admin/vehicles/makes')); ?>/${makeId}/models`)
            .then(res => res.json())
            .then(models => {
                modelSelect.innerHTML = '<option value="">Select Model</option>' +
                    models.map(m => `<option value="${m.id}">${m.name}</option>`).join('');
                modelSelect.disabled = false;
            });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/vehicles/index.blade.php ENDPATH**/ ?>