<?php
    $hasChildren = $item->children->isNotEmpty();
    $isActive = $item->isActive();
?>
<style>
    .vsp-sidebar__heading-wrapper {
        list-style: none;
    }

    .vsp-sidebar__heading-toggle {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        padding: 8px 16px;
        text-decoration: none;
        cursor: pointer;
    }

    .vsp-sidebar__heading-toggle .vsp-sidebar__heading {
        padding: 0;
    }

    .vsp-sidebar__heading-chevron {
        font-size: 11px;
        transition: transform 0.25s ease;
    }

    .vsp-sidebar__heading-toggle[aria-expanded="true"]
    .vsp-sidebar__heading-chevron {
        transform: rotate(180deg);
    }

    .vsp-sidebar__heading-submenu {
        margin: 0;
        padding: 0;
    }

    .vsp-sidebar__heading-submenu > li > a {
        padding-left: 24px;
    }
</style>
<?php if($item->isHeading()): ?>

    
    <?php if($hasChildren): ?>

        <li class="vsp-sidebar__heading-wrapper">

            <a href="#vspHeading<?php echo e($item->id); ?>"
               data-bs-toggle="collapse"
               role="button"
               aria-expanded="<?php echo e($isActive ? 'true' : 'false'); ?>"
               aria-controls="vspHeading<?php echo e($item->id); ?>"
               class="vsp-sidebar__heading-toggle">

                <span class="vsp-sidebar__heading">
                    <?php echo e($item->name); ?>

                </span>

                <i class="bi bi-chevron-down vsp-sidebar__heading-chevron"></i>

            </a>

            <ul id="vspHeading<?php echo e($item->id); ?>"
                class="collapse <?php echo e($isActive ? 'show' : ''); ?> vsp-sidebar__heading-submenu list-unstyled">

                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('backend.layouts.partials.sidebar-item', [
                        'item' => $child
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </li>

    <?php else: ?>

        
        <li class="vsp-sidebar__heading">
            <?php echo e($item->name); ?>

        </li>

    <?php endif; ?>

<?php elseif($hasChildren): ?>

    
    <li>

        <a href="#vspSubmenu<?php echo e($item->id); ?>"
           data-bs-toggle="collapse"
           role="button"
           aria-expanded="<?php echo e($isActive ? 'true' : 'false'); ?>"
           aria-controls="vspSubmenu<?php echo e($item->id); ?>"
           class="vsp-sidebar__parent-link <?php echo e($isActive ? 'active' : ''); ?>">

            <i class="bi <?php echo e($item->icon ?: 'bi-dot'); ?>"></i>

            <span><?php echo e($item->name); ?></span>

            <i class="bi bi-chevron-down vsp-sidebar__chevron ms-auto"></i>

        </a>

        <ul id="vspSubmenu<?php echo e($item->id); ?>"
            class="collapse <?php echo e($isActive ? 'show' : ''); ?> vsp-sidebar__submenu list-unstyled">

            <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php echo $__env->make('backend.layouts.partials.sidebar-item', [
                    'item' => $child
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </li>

<?php else: ?>

    
    <li>

        <a href="<?php echo e($item->resolveUrl()); ?>"
           <?php if($item->target === '_blank'): ?>
               target="_blank"
               rel="noopener"
           <?php endif; ?>
           class="<?php echo e($isActive ? 'active' : ''); ?>">

            <i class="bi <?php echo e($item->icon ?: 'bi-dot'); ?>"></i>

            <span><?php echo e($item->name); ?></span>

        </a>

    </li>

<?php endif; ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/layouts/partials/sidebar-item.blade.php ENDPATH**/ ?>