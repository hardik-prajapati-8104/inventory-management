<?php $__env->startSection('title'); ?>
Spare Parts - Vehicle Spare Parts Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-md-7">
            <h4 class="page-title mb-1">Spare Parts</h4>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><span>Spare Parts</span></li>
            </ul>
        </div>
        <div class="col-md-5 text-md-end mt-2 mt-md-0">
            <a href="<?php echo e(route('catalogue.index')); ?>" target="_blank" class="btn btn-outline-secondary"><i class="bi bi-globe"></i> View Public Catalogue</a>
            <button type="button" id="printSelectedBtn" class="btn btn-outline-secondary" disabled><i class="bi bi-upc-scan"></i> Print Selected Barcodes</button>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.import')): ?>
            <a href="<?php echo e(route('admin.spare-parts.import.create')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-upload"></i> Import
            </a>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.create')): ?>
            <a href="<?php echo e(route('admin.spare-parts.create')); ?>" class="btn btn-add text-white">
                <i class="bi bi-plus-lg"></i> Add Spare Part
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="card mb-3">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.spare-parts.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="small mb-1">Search</label>
                <input type="text" name="q" class="form-control" placeholder="Name, part number, SKU, barcode, OEM, vehicle…" value="<?php echo e(request('q')); ?>">
            </div>
            <div class="col-md-3">
                <label class="small mb-1">Category</label>
                <select name="category_id" class="form-select">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category_id') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="small mb-1">Brand</label>
                <select name="brand_id" class="form-select">
                    <option value="">All Brands</option>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->id); ?>" <?php echo e(request('brand_id') == $brand->id ? 'selected' : ''); ?>><?php echo e($brand->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="small mb-1">Stock</label>
                <select name="stock" class="form-select">
                    <option value="">Any</option>
                    <option value="in" <?php echo e(request('stock') == 'in' ? 'selected' : ''); ?>>In Stock</option>
                    <option value="low" <?php echo e(request('stock') == 'low' ? 'selected' : ''); ?>>Low Stock</option>
                    <option value="out" <?php echo e(request('stock') == 'out' ? 'selected' : ''); ?>>Out of Stock</option>
                </select>
            </div>
            <div class="col-12 mt-2">
                <button type="submit" class="btn btn-add text-white btn-sm"><i class="bi bi-search"></i> Search</button>
                <a href="<?php echo e(route('admin.spare-parts.index')); ?>" class="btn btn-outline-secondary btn-sm">Clear</a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead>
                    <tr>
                        <th width="2%"><input type="checkbox" id="selectAllParts"></th>
                        <th>Part</th>
                        <th>Part No. / SKU</th>
                        <th>Vehicle</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Purchase Price</th>
                        <th>Retail Price</th>
                        <th>Stock</th>
                        <th>Stock Value</th>
                        <th>Status</th>
                        <th width="10%">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $spareParts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><input type="checkbox" class="part-check" value="<?php echo e($part->id); ?>"></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if($part->main_image): ?>
                                    <img src="<?php echo e(asset('storage/'.$part->main_image)); ?>" class="rounded" width="36" height="36" style="object-fit:cover;">
                                <?php else: ?>
                                    <span class="vsp-avatar" style="width:36px;height:36px;"><i class="bi bi-gear-wide-connected"></i></span>
                                <?php endif; ?>
                                <div>
                                    <div class="fw-medium"><?php echo e($part->name); ?></div>
                                    <div class="small text-muted"><?php echo e($part->oem_number ?? '—'); ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div><?php echo e($part->part_number); ?></div>
                            <div class="small text-muted"><?php echo e($part->sku); ?></div>
                        </td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $part->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span class="badge bg-light text-dark border mb-1"><?php echo e($variant->label); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($part->category->name ?? '-'); ?></td>
                        <td><?php echo e($part->brand->name ?? '-'); ?></td>
                        <td>₹<?php echo e(number_format($part->purchase_price, 2)); ?></td>
                        <td>₹<?php echo e(number_format($part->retail_price, 2)); ?></td>
                        <td>
                            <?php if($part->current_stock <= 0): ?>
                                <span class="badge bg-danger">⚠ OUT OF STOCK</span>
                            <?php elseif($part->current_stock <= $part->minimum_stock): ?>
                                <span class="badge" style="background:var(--vsp-warning)">⚠ LOW STOCK (<?php echo e($part->current_stock); ?>)</span>
                            <?php else: ?>
                                <span class="badge bg-success"><?php echo e($part->current_stock); ?> <?php echo e($part->unit->short_code ?? ''); ?></span>
                            <?php endif; ?>
                            <?php if($part->minimum_stock > 0): ?>
                                <div class="small text-muted mt-1">Min: <?php echo e($part->minimum_stock); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>₹<?php echo e(number_format($part->current_stock * $part->purchase_price, 2)); ?></td>
                        <td>
                            <?php if($part->status === 'active'): ?> <span class="badge bg-success">Active</span>
                            <?php elseif($part->status === 'inactive'): ?> <span class="badge bg-secondary">Inactive</span>
                            <?php else: ?> <span class="badge bg-danger">Discontinued</span> <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">&#x22EE;</button>
                                <ul class="dropdown-menu">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.edit')): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.spare-parts.edit', $part->id)); ?>"><i class="bi bi-pencil me-1"></i> Edit</a></li>
                                    <?php endif; ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.spare-parts.barcode', $part->id)); ?>" target="_blank"><i class="bi bi-upc-scan me-1"></i> Print Barcode</a></li>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.create')): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('admin.spare-parts.duplicate', $part->id)); ?>"><i class="bi bi-copy me-1"></i> Clone</a></li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.delete')): ?>
                                    <li>
                                        <a class="dropdown-item text-danger" href="#" onclick="event.preventDefault(); document.getElementById('del-<?php echo e($part->id); ?>').submit();"><i class="bi bi-trash me-1"></i> Delete</a>
                                        <form id="del-<?php echo e($part->id); ?>" action="<?php echo e(route('admin.spare-parts.destroy', $part->id)); ?>" method="POST" class="d-none"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?></form>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="12" class="text-center text-muted py-4">No spare parts found. Try adjusting your search or <a href="<?php echo e(route('admin.spare-parts.create')); ?>">add a new one</a>.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo e($spareParts->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function updatePrintButton() {
        const checked = document.querySelectorAll('.part-check:checked').length;
        const btn = document.getElementById('printSelectedBtn');
        btn.disabled = checked === 0;
        btn.textContent = checked ? `🖨 Print ${checked} Barcode(s)` : 'Print Selected Barcodes';
    }

    document.getElementById('selectAllParts')?.addEventListener('change', function () {
        document.querySelectorAll('.part-check').forEach(cb => cb.checked = this.checked);
        updatePrintButton();
    });

    document.querySelectorAll('.part-check').forEach(cb => cb.addEventListener('change', updatePrintButton));

    document.getElementById('printSelectedBtn')?.addEventListener('click', function () {
        const ids = Array.from(document.querySelectorAll('.part-check:checked')).map(cb => cb.value);
        if (! ids.length) return;
        const params = ids.map(id => `ids[]=${id}`).join('&');
        window.open(`<?php echo e(route('admin.spare-parts.barcodes.bulk')); ?>?${params}`, '_blank');
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/spare-parts/index.blade.php ENDPATH**/ ?>