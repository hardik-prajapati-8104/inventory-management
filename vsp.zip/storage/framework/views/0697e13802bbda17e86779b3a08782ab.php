<?php $__env->startSection('title'); ?>
Warehouses - Vehicle Spare Parts Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-12">
            <h4 class="page-title mb-1">Warehouses</h4>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><span>Warehouses</span></li>
            </ul>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#whs" type="button">Warehouses (<?php echo e($warehouses->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#zones" type="button">Zones (<?php echo e($zones->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#racks" type="button">Racks (<?php echo e($racks->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#shelves" type="button">Shelves (<?php echo e($shelves->count()); ?>)</button></li>
            <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#bins" type="button">Bins (<?php echo e($bins->count()); ?>)</button></li>
        </ul>

        <div class="tab-content pt-4">

            
            <div class="tab-pane fade show active" id="whs">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Warehouse</h6>
                        <form action="<?php echo e(route('admin.warehouses.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2"><label>Name<span class="text-error">*</span></label><input type="text" name="name" required class="form-control" placeholder="e.g. Main Warehouse"></div>
                            <div class="mb-2"><label>Code<span class="text-error">*</span></label><input type="text" name="code" required class="form-control" placeholder="e.g. WH-A"></div>
                            <div class="mb-2"><label>Manager</label><input type="text" name="manager" class="form-control"></div>
                            <div class="mb-2"><label>Contact Number</label><input type="text" name="contact_number" class="form-control"></div>
                            <div class="mb-2"><label>City</label><input type="text" name="city" class="form-control"></div>
                            <div class="mb-3"><label>Address</label><textarea name="address" class="form-control"></textarea></div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Warehouse</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th>#</th><th>Name</th><th>Code</th><th>Manager</th><th>Parts Stocked</th><th>Default</th><th>Status</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($wh->name); ?></td>
                                    <td><?php echo e($wh->code); ?></td>
                                    <td><?php echo e($wh->manager ?? '-'); ?></td>
                                    <td><?php echo e($wh->stock_count); ?></td>
                                    <td><?php echo e($wh->is_default ? '⭐' : ''); ?></td>
                                    <td><?php echo e($wh->status ? 'Active' : 'Inactive'); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="7" class="text-center text-muted py-3">No warehouses yet — add one to start receiving stock.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="zones">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Zone</h6>
                        <form action="<?php echo e(route('admin.warehouses.zones.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Warehouse<span class="text-error">*</span></label>
                                <select name="warehouse_id" required class="form-select">
                                    <option value="">Select Warehouse</option>
                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($wh->id); ?>"><?php echo e($wh->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3"><label>Zone Name<span class="text-error">*</span></label><input type="text" name="name" required class="form-control" placeholder="e.g. Engine Zone"></div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Zone</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th>#</th><th>Warehouse</th><th>Zone</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($z->warehouse->name ?? '-'); ?></td><td><?php echo e($z->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="3" class="text-center text-muted py-3">No zones yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="racks">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Rack</h6>
                        <form action="<?php echo e(route('admin.warehouses.racks.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Warehouse<span class="text-error">*</span></label>
                                <select name="warehouse_id" id="rackWarehouse" required class="form-select">
                                    <option value="">Select Warehouse</option>
                                    <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($wh->id); ?>"><?php echo e($wh->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label>Zone (optional)</label>
                                <select name="warehouse_zone_id" class="form-select">
                                    <option value="">None</option>
                                    <?php $__currentLoopData = $zones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $z): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($z->id); ?>"><?php echo e($z->warehouse->name); ?> — <?php echo e($z->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3"><label>Rack Name<span class="text-error">*</span></label><input type="text" name="name" required class="form-control" placeholder="e.g. A-05"></div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Rack</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th>#</th><th>Warehouse</th><th>Zone</th><th>Rack</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($r->warehouse->name ?? '-'); ?></td><td><?php echo e($r->zone->name ?? '-'); ?></td><td><?php echo e($r->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4" class="text-center text-muted py-3">No racks yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="shelves">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Shelf</h6>
                        <form action="<?php echo e(route('admin.warehouses.shelves.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Rack<span class="text-error">*</span></label>
                                <select name="rack_id" required class="form-select">
                                    <option value="">Select Rack</option>
                                    <?php $__currentLoopData = $racks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($r->id); ?>"><?php echo e($r->warehouse->name); ?> — <?php echo e($r->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3"><label>Shelf Name<span class="text-error">*</span></label><input type="text" name="name" required class="form-control" placeholder="e.g. Shelf 03"></div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Shelf</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th>#</th><th>Warehouse</th><th>Rack</th><th>Shelf</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $shelves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($s->rack->warehouse->name ?? '-'); ?></td><td><?php echo e($s->rack->name ?? '-'); ?></td><td><?php echo e($s->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="4" class="text-center text-muted py-3">No shelves yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            
            <div class="tab-pane fade" id="bins">
                <div class="row">
                    <div class="col-md-4">
                        <h6 class="mb-3">Add Bin</h6>
                        <form action="<?php echo e(route('admin.warehouses.bins.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-2">
                                <label>Shelf<span class="text-error">*</span></label>
                                <select name="shelf_id" required class="form-select">
                                    <option value="">Select Shelf</option>
                                    <?php $__currentLoopData = $shelves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s->id); ?>"><?php echo e($s->rack->warehouse->name ?? ''); ?> — <?php echo e($s->rack->name ?? ''); ?> — <?php echo e($s->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="mb-3"><label>Bin Name<span class="text-error">*</span></label><input type="text" name="name" required class="form-control" placeholder="e.g. Bin 12"></div>
                            <button type="submit" class="btn btn-add text-white w-100"><i class="bi bi-plus-lg"></i> Add Bin</button>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped">
                            <thead><tr><th>#</th><th>Warehouse</th><th>Rack</th><th>Shelf</th><th>Bin</th></tr></thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $bins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($b->shelf->rack->warehouse->name ?? '-'); ?></td><td><?php echo e($b->shelf->rack->name ?? '-'); ?></td><td><?php echo e($b->shelf->name ?? '-'); ?></td><td><?php echo e($b->name); ?></td></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr><td colspan="5" class="text-center text-muted py-3">No bins yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/warehouses/index.blade.php ENDPATH**/ ?>