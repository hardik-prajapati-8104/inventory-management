<?php
    // Dynamic sidebar (Menu Management): the tree below already contains
    // only active items the current admin has permission to see — see
    // Menu::sidebarTree(). Nothing here re-checks permissions; that keeps
    // this partial dumb and the visibility rule defined in exactly one
    // place (the model).
    $menuTree = \App\Models\Menu::sidebarTree();
?>

<div class="vsp-sidebar__brand">
    <i class="bi bi-boxes"></i>
    <span class="vsp-sidebar__brand-text">VSP Inventory</span>
</div>

<nav class="vsp-sidebar__nav">
    <ul class="list-unstyled">
        <?php $__empty_1 = true; $__currentLoopData = $menuTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make('backend.layouts.partials.sidebar-item', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
            <li class="px-3 py-2 small text-muted">
                No menu items configured.
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menu.create')): ?>
                    <a href="<?php echo e(route('admin.menus.create')); ?>" class="text-decoration-underline">Add one</a>.
                <?php endif; ?>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/layouts/partials/sidebar.blade.php ENDPATH**/ ?>