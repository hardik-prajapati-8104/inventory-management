<?php $__env->startSection('title'); ?>
Edit Menu - Vehicle Spare Parts Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-12">
            <h4 class="page-title mb-1">Edit Menu — <?php echo e($menu->name); ?></h4>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('admin.menus.index')); ?>">Menu Management</a></li>
                <li><span>Edit Menu</span></li>
            </ul>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('admin.menus.update', $menu->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('backend.menus._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="mt-4">
                <button type="submit" class="btn btn-add text-white pr-4 pl-4"><i class="bi bi-check-lg"></i> Save Changes</button>
                <a href="<?php echo e(route('admin.menus.index')); ?>" class="btn btn-outline-secondary pr-4 pl-4">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/menus/edit.blade.php ENDPATH**/ ?>