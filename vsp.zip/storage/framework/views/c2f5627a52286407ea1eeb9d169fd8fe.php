<?php $__env->startSection('title'); ?>
Manufacturers - Vehicle Spare Parts Inventory
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>

<div class="page-title-area">
    <div class="row align-items-center">
        <div class="col-md-8">
            <h4 class="page-title mb-1">Manufacturers</h4>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                <li><span>Manufacturers</span></li>
            </ul>
        </div>
        <div class="col-md-4 text-md-end mt-2 mt-md-0">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.create')): ?>
            <button type="button" class="btn btn-add text-white" data-bs-toggle="modal" data-bs-target="#createManufacturerModal">
                <i class="bi bi-plus-lg"></i> Add Manufacturer
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead><tr><th width="3%">#</th><th>Name</th><th>Country</th><th>Status</th><th width="10%">Action</th></tr></thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($m->name); ?></td>
                        <td><?php echo e($m->country ?? '-'); ?></td>
                        <td>
                            <?php if($m->status): ?> <span class="badge bg-success">Active</span>
                            <?php else: ?> <span class="badge bg-secondary">Inactive</span> <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.edit')): ?>
                            <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#editManufacturerModal<?php echo e($m->id); ?>"><i class="bi bi-pencil"></i></button>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('spare-part.delete')): ?>
                            <form action="<?php echo e(route('admin.manufacturers.destroy', $m->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this manufacturer?');">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <div class="modal fade" id="editManufacturerModal<?php echo e($m->id); ?>" tabindex="-1">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="<?php echo e(route('admin.manufacturers.update', $m->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <div class="modal-header"><h6 class="modal-title">Edit Manufacturer</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                    <div class="modal-body">
                                        <div class="mb-3">
                                            <label>Name<span class="text-error">*</span></label>
                                            <input type="text" name="name" required class="form-control" value="<?php echo e($m->name); ?>">
                                        </div>
                                        <div class="mb-0">
                                            <label>Country</label>
                                            <input type="text" name="country" class="form-control" value="<?php echo e($m->country); ?>">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-add text-white">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No manufacturers yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="createManufacturerModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.manufacturers.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header"><h6 class="modal-title">Add Manufacturer</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label>Name<span class="text-error">*</span></label>
                        <input type="text" name="name" required class="form-control" placeholder="e.g. Denso">
                    </div>
                    <div class="mb-0">
                        <label>Country</label>
                        <input type="text" name="country" class="form-control" placeholder="e.g. Japan">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-add text-white">Save Manufacturer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\server\www\laravel\vsp\resources\views/backend/manufacturers/index.blade.php ENDPATH**/ ?>